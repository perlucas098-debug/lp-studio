import express from "express";
import cors from "cors";
import morgan from "morgan";
import fetch from "node-fetch";
import dotenv from "dotenv";
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "20mb" }));
app.use(morgan("dev"));

const PORT = process.env.PORT || 8787;

// ----------- Helpers -----------
const ok = (res, data) => res.json(data);
const fail = (res, e) => res.status(500).json({ error: String(e) });

// ----------- Mock/Real endpoints -----------
// Replace bodies with calls to Replicate / Stability / Together providers.
app.post("/txt2img", async (req, res) => {
  try {
    const { prompt, size } = req.body || {};
    // MOCK: return a placeholder image based on seed
    const seed = encodeURIComponent(prompt || size || Math.random().toString(36).slice(2));
    ok(res, { image: `https://picsum.photos/seed/${seed}/1024/1024` });
  } catch (e) { fail(res, e); }
});

app.post("/img2img", async (req, res) => {
  try {
    ok(res, { image: `https://picsum.photos/seed/img2img_${Date.now()}/1024/1024` });
  } catch (e) { fail(res, e); }
});

app.post("/faceswap", async (req, res) => {
  try {
    ok(res, { image: `https://picsum.photos/seed/faceswap_${Date.now()}/1024/1024` });
  } catch (e) { fail(res, e); }
});

app.post("/upscale", async (req, res) => {
  try {
    ok(res, { image: `https://picsum.photos/seed/upscale_${Date.now()}/2048/2048` });
  } catch (e) { fail(res, e); }
});

app.post("/interrogate", async (req, res) => {
  try {
    ok(res, { prompt: "Descripción estimada de la imagen con estilo, luz y elementos principales." });
  } catch (e) { fail(res, e); }
});

app.post("/img2video", async (req, res) => {
  try {
    ok(res, { video: "https://www.w3schools.com/html/mov_bbb.mp4" });
  } catch (e) { fail(res, e); }
});

app.post("/lora", async (req, res) => {
  try {
    ok(res, { modelId: `lora_${Math.floor(Math.random()*9999)}` });
  } catch (e) { fail(res, e); }
});

app.get("/", (req, res) => res.json({ ok: true, service: "LP Studio API" }));

app.listen(PORT, () => console.log("LP Studio API on", PORT));
