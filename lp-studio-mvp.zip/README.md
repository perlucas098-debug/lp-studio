# LP Studio — Pykaso-like (MVP)

**Stack**: Vite + React (frontend) · Express (backend) · Tailwind por CDN (simple).
Listo para deploy en **Vercel** (monorepo) o levantar local.

## Local (rápido)
1. `cd backend && npm i && npm run dev`  (API en http://localhost:8787)
2. En otra terminal: `cd ../frontend && npm i && npm run dev`  (web en http://localhost:5173)
3. El frontend llama a `/api/...`. Si desplegás juntos en Vercel, no cambies nada.
   Para local, podés usar un proxy en `vite.config.js` o correr ambos en el mismo dominio.

## Deploy en Vercel (monorepo)
1. Subí este repo a GitHub.
2. Importá el repo en Vercel.
3. En **Project Settings → Monorepo**:
   - **frontend**: directorio = `frontend`, Build Command = `npm run build`, Output = `dist`.
   - **backend**: directorio = `backend`, Framework = `Other`, Output dir (vacío).
4. En **Routes** usa `vercel.json` incluido para enrutar `/api/*` al backend.
5. Configurá variables de entorno en el backend si conectás proveedores reales (Replicate, Stability, etc.).

## Rutas API (mock)
POST /api/txt2img
POST /api/img2img
POST /api/faceswap
POST /api/upscale
POST /api/interrogate
POST /api/img2video
POST /api/lora

> Para producción: reemplazá los mocks por llamadas reales.
