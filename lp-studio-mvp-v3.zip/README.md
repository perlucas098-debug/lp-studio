# LP Studio — Pykaso-like (MVP v3)

**Listo para Vercel (monorepo)** y para ejecutar local en Windows con doble click.

## Deploy en Vercel
1. Subí esta carpeta a GitHub.
2. Importá el repo en Vercel.
3. No toques nada: `vercel.json` ya enruta `/api/*` al backend y sirve el frontend.
4. Al terminar, Vercel te da la URL pública.

## Local (Windows)
1. Doble click a `_INICIAR_BACKEND.bat` (API en http://localhost:8787)
2. Doble click a `_INICIAR_FRONTEND.bat` (Web en http://localhost:5173)

## API (mock, lista para cambiar a IA real)
POST /api/txt2img
POST /api/img2img
POST /api/faceswap
POST /api/upscale
POST /api/interrogate
POST /api/img2video
POST /api/lora

Para IA real: creá `REPLICATE_API_TOKEN` y agregalo en Vercel → Settings → Environment Variables.
