import React, { useMemo, useState } from "react";

const BRAND_NAME = "LP Studio";
const BRAND_ACCENT = "#f97316"; // naranja
const BRAND_ACCENT_2 = "#fb923c";

let ID = 1;
const mkId = () => `${Date.now()}_${ID++}`;

function useJobQueue() {
  const [jobs, setJobs] = useState([]);

  const createJob = async (type, input) => {
    const id = mkId();
    const job = { id, type, input, status: "queued", progress: 0, createdAt: new Date().toISOString() };
    setJobs((j) => [job, ...j]);
    try {
      const res = await fetch(`/api/${type}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input || {}) });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setJobs((prev) => prev.map((x) => (x.id === id ? { ...x, status: "succeeded", progress: 100, output: data } : x)));
    } catch (e) {
      setJobs((prev) => prev.map((x) => (x.id === id ? { ...x, status: "failed", progress: 100, error: String(e) } : x)));
    }
  };

  const cancelJob = (id) => setJobs((j) => j.filter((x) => x.id !== id));
  return { jobs, createJob, cancelJob };
}

function Card({ title, subtitle, children, right }) {
  return (
    <div className="bg-slate-900/60 border border-white/10 rounded-2xl shadow-xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold">{title}</h3>
          {subtitle && <p className="text-slate-400 text-sm mt-0.5">{subtitle}</p>}
        </div>
        {right}
      </div>
      <div className="mt-3">{children}</div>
    </div>
  );
}

function Labeled({ label, children }) {
  return (
    <label className="grid gap-1 text-sm">
      <span className="text-slate-400">{label}</span>
      {children}
    </label>
  );
}
function Button({ children, className = "", ...props }) {
  return (
    <button
      className={`px-4 py-2 rounded-xl font-semibold border border-white/10 shadow-md hover:opacity-90 active:opacity-80 ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
function FileInput({ accept, onFile }) {
  return (
    <input
      type="file"
      accept={accept}
      className="block w-full text-sm file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:font-medium file:bg-slate-800 file:text-slate-100 hover:file:bg-slate-700"
      onChange={(e) => {
        const f = e.target.files?.[0];
        if (f) onFile(f);
      }}
    />
  );
}

function Txt2Img({ onSubmit }) {
  const [prompt, setPrompt] = useState("");
  const [steps, setSteps] = useState(20);
  const [cfg, setCfg] = useState(4.0);
  const [size, setSize] = useState("1024x1024");
  return (
    <Card title="Imagen (Texto → Imagen)" subtitle="Modelos sugeridos: SDXL, FLUX">
      <div className="grid gap-3">
        <Labeled label="Prompt">
          <textarea className="bg-slate-950/60 rounded-xl p-3 border border-white/10" rows={3} value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Ej: mujer realista, luz suave, 50mm, fondo urbano" />
        </Labeled>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Labeled label="Pasos">
            <input type="number" min={10} max={50} className="bg-slate-950/60 rounded-xl p-2 border border-white/10" value={steps} onChange={(e) => setSteps(+e.target.value)} />
          </Labeled>
          <Labeled label="CFG">
            <input type="number" step="0.5" min={1} max={12} className="bg-slate-950/60 rounded-xl p-2 border border-white/10" value={cfg} onChange={(e) => setCfg(+e.target.value)} />
          </Labeled>
          <Labeled label="Tamaño">
            <select className="bg-slate-950/60 rounded-xl p-2 border border-white/10" value={size} onChange={(e) => setSize(e.target.value)}>
              {["1024x1024","768x1344","1344x768"].map(s => <option key={s}>{s}</option>)}
            </select>
          </Labeled>
        </div>
        <Button style={{ background: BRAND_ACCENT, color: "#06131c" }} onClick={() => onSubmit({ prompt, steps, cfg, size })}>
          Generar
        </Button>
      </div>
    </Card>
  );
}

function FaceSwap({ onSubmit }) {
  const [src, setSrc] = useState(null);
  const [face, setFace] = useState(null);
  return (
    <Card title="Face Swap" subtitle="Subí el video/imagen base y la cara de tu personaje">
      <div className="grid gap-3">
        <Labeled label="Base (imagen o video)"><FileInput accept="image/*,video/*" onFile={setSrc} /></Labeled>
        <Labeled label="Cara (primer plano)"><FileInput accept="image/*" onFile={setFace} /></Labeled>
        <div className="flex gap-2">
          <Button onClick={() => onSubmit({ srcName: src?.name, faceName: face?.name })} style={{ background: BRAND_ACCENT, color: "#06131c" }}>Intercambiar</Button>
          <p className="text-xs text-slate-400 self-center">Asegurate de tener consentimiento para cualquier rostro real.</p>
        </div>
      </div>
    </Card>
  );
}

function Img2Img({ onSubmit }) {
  const [img, setImg] = useState(null);
  const [prompt, setPrompt] = useState("");
  const [strength, setStrength] = useState(0.6);
  return (
    <Card title="Image → Image" subtitle="Reinterpreta una foto conservando pose/iluminación">
      <div className="grid gap-3">
        <Labeled label="Imagen base"><FileInput accept="image/*" onFile={setImg} /></Labeled>
        <Labeled label="Instrucciones (prompt)"><input className="bg-slate-950/60 rounded-xl p-2 border border-white/10" placeholder="Ej: misma pose, outfit naranja, estilo realista" value={prompt} onChange={(e) => setPrompt(e.target.value)} /></Labeled>
        <Labeled label={`Fuerza (${strength})`}><input type="range" min={0.1} max={1} step={0.1} value={strength} onChange={(e) => setStrength(+e.target.value)} /></Labeled>
        <Button style={{ background: BRAND_ACCENT, color: "#06131c" }} onClick={() => onSubmit({ name: img?.name, prompt, strength })}>Generar</Button>
      </div>
    </Card>
  );
}

function Upscaler({ onSubmit }) {
  const [img, setImg] = useState(null);
  const [scale, setScale] = useState(4);
  return (
    <Card title="Upscaler" subtitle="Mejorá piel y detalles (Real‑ESRGAN / CodeFormer)">
      <div className="grid gap-3">
        <Labeled label="Imagen"><FileInput accept="image/*" onFile={setImg} /></Labeled>
        <Labeled label="Escala">
          <select className="bg-slate-950/60 rounded-xl p-2 border border-white/10" value={scale} onChange={(e) => setScale(+e.target.value)}>
            <option value={2}>2x</option>
            <option value={4}>4x</option>
          </select>
        </Labeled>
        <Button style={{ background: BRAND_ACCENT, color: "#06131c" }} onClick={() => onSubmit({ name: img?.name, scale })}>Mejorar</Button>
      </div>
    </Card>
  );
}

function Interrogate({ onSubmit }) {
  const [img, setImg] = useState(null);
  return (
    <Card title="Image → Prompt" subtitle="Saca un prompt descriptivo de una imagen (BLIP/CLIP)">
      <div className="grid gap-3">
        <Labeled label="Imagen"><FileInput accept="image/*" onFile={setImg} /></Labeled>
        <Button style={{ background: BRAND_ACCENT, color: "#06131c" }} onClick={() => onSubmit({ name: img?.name })}>Describir imagen</Button>
      </div>
    </Card>
  );
}

function Img2Video({ onSubmit }) {
  const [img, setImg] = useState(null);
  const [seconds, setSeconds] = useState(4);
  return (
    <Card title="Imagen → Video" subtitle="Anima una foto a clip corto">
      <div className="grid gap-3">
        <Labeled label="Imagen"><FileInput accept="image/*" onFile={setImg} /></Labeled>
        <Labeled label="Duración (s)"><input type="number" min={2} max={10} className="bg-slate-950/60 rounded-xl p-2 border border-white/10" value={seconds} onChange={(e) => setSeconds(+e.target.value)} /></Labeled>
        <Button style={{ background: BRAND_ACCENT, color: "#06131c" }} onClick={() => onSubmit({ name: img?.name, seconds })}>Generar video</Button>
      </div>
    </Card>
  );
}

function LoRA({ onSubmit }) {
  const [zip, setZip] = useState(null);
  const [epochs, setEpochs] = useState(6);
  return (
    <Card title="LoRA Training (beta)" subtitle="Entrená el estilo (requiere backend GPU)" right={<span className="text-xs text-amber-300">GPU</span>}>
      <div className="grid gap-3">
        <Labeled label="Dataset (.zip con 15–50 fotos)"><FileInput accept="application/zip" onFile={setZip} /></Labeled>
        <Labeled label="Épocas"><input type="number" min={1} max={40} className="bg-slate-950/60 rounded-xl p-2 border border-white/10" value={epochs} onChange={(e) => setEpochs(+e.target.value)} /></Labeled>
        <Button style={{ background: BRAND_ACCENT, color: "#06131c" }} onClick={() => onSubmit({ name: zip?.name, epochs })}>Entrenar LoRA</Button>
      </div>
    </Card>
  );
}

function Queue({ jobs, onCancel }) {
  return (
    <Card title="Cola de Tareas" subtitle="Seguimiento y descargas">
      <div className="grid gap-3">
        {jobs.length === 0 && <p className="text-slate-400">No hay tareas todavía.</p>}
        {jobs.map((j) => (
          <div key={j.id} className="border border-white/10 rounded-xl p-3">
            <div className="flex items-center justify-between">
              <div className="text-sm"><b>{j.type}</b> · <span className="text-slate-400">{new Date(j.createdAt).toLocaleTimeString()}</span></div>
              <div className="text-xs"><span className={j.status === "succeeded" ? "text-emerald-400" : j.status === "running" ? "text-sky-300" : "text-slate-300"}>{j.status}</span></div>
            </div>
            <div className="mt-2 h-2 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full" style={{ background: BRAND_ACCENT, width: `${j.progress ?? 100}%` }} />
            </div>
            {j.output?.image && (<a href={j.output.image} download className="block mt-3"><img alt="resultado" src={j.output.image} className="rounded-lg border border-white/10" /></a>)}
            {j.output?.video && (<video src={j.output.video} controls className="rounded-lg border border-white/10 w-full mt-3" />)}
            {j.output?.prompt && <p className="text-slate-300 text-sm mt-2">{j.output.prompt}</p>}
            {j.output?.modelId && <p className="text-slate-300 text-sm mt-2">Modelo entrenado: <b>{j.output.modelId}</b></p>}
            <div className="mt-3 flex gap-2">
              <Button className="text-slate-200" onClick={() => onCancel(j.id)}>Eliminar</Button>
              {j.output?.image && (<a className="px-4 py-2 rounded-xl font-semibold border border-white/10 shadow-md" style={{ background: "#10b981", color: "#05251f" }} href={j.output.image} download>Descargar</a>)}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

export default function App() {
  const { jobs, createJob, cancelJob } = useJobQueue();
  const [tab, setTab] = useState("txt2img");
  const tabs = [
    { id: "txt2img", label: "Texto→Imagen" },
    { id: "faceswap", label: "Face Swap" },
    { id: "img2img", label: "Imagen→Imagen" },
    { id: "upscale", label: "Upscaler" },
    { id: "interrogate", label: "Img→Prompt" },
    { id: "img2video", label: "Imagen→Video" },
    { id: "lora", label: "LoRA" },
    { id: "queue", label: "Cola" },
  ];
  const submitters = React.useMemo(() => ({
    txt2img: (payload) => createJob("txt2img", payload),
    faceswap: (payload) => createJob("faceswap", payload),
    img2img: (payload) => createJob("img2img", payload),
    upscale: (payload) => createJob("upscale", payload),
    interrogate: (payload) => createJob("interrogate", payload),
    img2video: (payload) => createJob("img2video", payload),
    lora: (payload) => createJob("lora", payload),
  }), [createJob]);

  return (
    <div className="min-h-screen text-slate-100" style={{ background: "#0b1020" }}>
      <header className="sticky top-0 z-50 border-b border-white/10 bg-slate-900/60 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl" style={{ background: `linear-gradient(135deg, ${BRAND_ACCENT}, ${BRAND_ACCENT_2})` }} />
            <b className="tracking-tight">{BRAND_NAME}</b>
            <span className="text-xs text-slate-400 hidden md:inline">— Generador de contenido IA</span>
          </div>
          <nav className="flex gap-2 overflow-x-auto">
            {tabs.map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)} className={`px-3 py-1.5 rounded-lg text-sm border ${tab === t.id ? "bg-orange-500/20 border-orange-400/40" : "border-white/10"}`}>
                {t.label}
              </button>
            ))}
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 py-6 grid gap-4">
        {tab === "txt2img" && <Txt2Img onSubmit={submitters.txt2img} />}
        {tab === "faceswap" && <FaceSwap onSubmit={submitters.faceswap} />}
        {tab === "img2img" && <Img2Img onSubmit={submitters.img2img} />}
        {tab === "upscale" && <Upscaler onSubmit={submitters.upscale} />}
        {tab === "interrogate" && <Interrogate onSubmit={submitters.interrogate} />}
        {tab === "img2video" && <Img2Video onSubmit={submitters.img2video} />}
        {tab === "lora" && <LoRA onSubmit={submitters.lora} />}
        {tab === "queue" && <Queue jobs={jobs} onCancel={cancelJob} />}
        {tab !== "queue" && <Queue jobs={jobs} onCancel={cancelJob} />}
      </main>
      <footer className="max-w-6xl mx-auto px-4 pb-12 pt-2 text-slate-400 text-sm">
        <p>Demo lista para Vercel. Agregá claves en Settings → Environment Variables para activar IA real.</p>
      </footer>
    </div>
  );
}
